// routes/orders.js — Orders & Stripe Payment

const express = require('express');
const router  = express.Router();
const Order   = require('../models/Order');
const Cart    = require('../models/Cart');
const Product = require('../models/Product');
const { protect } = require('../middleware/auth');
const { admin }   = require('../middleware/admin');
const stripe      = require('stripe')(process.env.STRIPE_SECRET_KEY);

router.use(protect);

// ─────────────────────────────────────────────────────────────
// POST /api/orders/checkout
// Create Stripe payment intent & place order
// Body: { shippingAddress }
// ─────────────────────────────────────────────────────────────
router.post('/checkout', async (req, res) => {
  try {
    const { shippingAddress } = req.body;

    // Get user's cart
    const cart = await Cart.findOne({ user: req.user._id })
      .populate('items.product', 'name images price stock');

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Cart is empty' });
    }

    // Calculate prices
    const itemsTotal   = cart.items.reduce((t, i) => t + i.price * i.quantity, 0);
    const shippingPrice = itemsTotal > 100 ? 0 : 9.99;   // free shipping over $100
    const taxPrice      = +(itemsTotal * 0.1).toFixed(2); // 10% tax
    const totalPrice    = +(itemsTotal + shippingPrice + taxPrice).toFixed(2);

    // Create Stripe payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount:   Math.round(totalPrice * 100), // Stripe uses cents
      currency: 'usd',
      metadata: { userId: req.user._id.toString() }
    });

    // Create order in DB
    const order = await Order.create({
      user: req.user._id,
      items: cart.items.map(item => ({
        product:  item.product._id,
        name:     item.product.name,
        image:    item.product.images[0] || '',
        price:    item.price,
        quantity: item.quantity,
        size:     item.size,
        color:    item.color
      })),
      shippingAddress,
      totalPrice,
      shippingPrice,
      taxPrice,
      paymentResult: {
        id:     paymentIntent.id,
        status: paymentIntent.status,
        email:  req.user.email
      }
    });

    // Reduce stock for each product
    for (const item of cart.items) {
      await Product.findByIdAndUpdate(item.product._id, {
        $inc: { stock: -item.quantity }
      });
    }

    // Clear the cart
    await Cart.findOneAndDelete({ user: req.user._id });

    res.status(201).json({
      order,
      clientSecret: paymentIntent.client_secret  // send to frontend for Stripe.js
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// PUT /api/orders/:id/pay
// Mark order as paid (called after Stripe confirms payment)
// Body: { paymentIntentId }
// ─────────────────────────────────────────────────────────────
router.put('/:id/pay', async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Order not found' });

    order.isPaid  = true;
    order.paidAt  = new Date();
    order.status  = 'processing';
    order.paymentResult.status = 'succeeded';

    const updated = await order.save();
    res.json(updated);

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/orders/my
// Get all orders for the logged in user
// ─────────────────────────────────────────────────────────────
router.get('/my', async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/orders/:id
// Get single order by ID (own order only)
// ─────────────────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).populate('user', 'name email');

    if (!order) return res.status(404).json({ message: 'Order not found' });

    // Only allow owner or admin
    if (order.user._id.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorised' });
    }

    res.json(order);

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
