// routes/products.js — Product listing, search & filter

const express = require('express');
const router  = express.Router();
const Product = require('../models/Product');
const { protect } = require('../middleware/auth');
const { admin }   = require('../middleware/admin');
const multer = require('multer');
const path   = require('path');

// ── IMAGE UPLOAD SETUP (multer) ──────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename:    (req, file, cb) => {
    cb(null, `product-${Date.now()}${path.extname(file.originalname)}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp/;
    const isValid = allowed.test(path.extname(file.originalname).toLowerCase());
    isValid ? cb(null, true) : cb(new Error('Only image files allowed'));
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/products
// Get all products with search, filter & pagination
//
// Query params:
//   ?search=dress
//   ?category=tops
//   ?minPrice=10&maxPrice=100
//   ?size=M
//   ?color=black
//   ?sort=price_asc | price_desc | newest | rating
//   ?page=1&limit=12
// ─────────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const {
      search,
      category,
      minPrice,
      maxPrice,
      size,
      color,
      sort,
      page  = 1,
      limit = 12
    } = req.query;

    // Build filter object
    const filter = {};

    // Text search
    if (search) {
      filter.$text = { $search: search };
    }

    // Category filter
    if (category) {
      filter.category = category;
    }

    // Price range filter
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }

    // Size filter
    if (size) {
      filter.sizes = { $in: [size] };
    }

    // Color filter
    if (color) {
      filter.colors = { $in: [color] };
    }

    // Sort options
    let sortOption = {};
    switch (sort) {
      case 'price_asc':  sortOption = { price:  1 }; break;
      case 'price_desc': sortOption = { price: -1 }; break;
      case 'rating':     sortOption = { rating: -1 }; break;
      case 'newest':
      default:           sortOption = { createdAt: -1 };
    }

    // Pagination
    const skip  = (Number(page) - 1) * Number(limit);
    const total = await Product.countDocuments(filter);

    const products = await Product.find(filter)
      .sort(sortOption)
      .skip(skip)
      .limit(Number(limit));

    res.json({
      products,
      page:       Number(page),
      totalPages: Math.ceil(total / Number(limit)),
      total
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/products/featured
// Get featured products (for homepage)
// ─────────────────────────────────────────────────────────────
router.get('/featured', async (req, res) => {
  try {
    const products = await Product.find({ isFeatured: true }).limit(8);
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/products/:id
// Get single product by ID
// ─────────────────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json(product);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/products
// Create a new product (admin only)
// ─────────────────────────────────────────────────────────────
router.post('/', protect, admin, upload.array('images', 5), async (req, res) => {
  try {
    const { name, description, price, category, sizes, colors, stock, isFeatured } = req.body;

    // Get uploaded image paths
    const images = req.files ? req.files.map(f => `/uploads/${f.filename}`) : [];

    const product = await Product.create({
      name,
      description,
      price:      Number(price),
      category,
      sizes:      sizes ? JSON.parse(sizes) : [],
      colors:     colors ? JSON.parse(colors) : [],
      images,
      stock:      Number(stock),
      isFeatured: isFeatured === 'true'
    });

    res.status(201).json(product);

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// PUT /api/products/:id
// Update a product (admin only)
// ─────────────────────────────────────────────────────────────
router.put('/:id', protect, admin, async (req, res) => {
  try {
    const product = await Product.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.json(product);

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// DELETE /api/products/:id
// Delete a product (admin only)
// ─────────────────────────────────────────────────────────────
router.delete('/:id', protect, admin, async (req, res) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.json({ message: 'Product deleted successfully' });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
