// routes/cart.js — Shopping Cart

const express = require('express');
const router  = express.Router();
const Cart    = require('../models/Cart');
const Product = require('../models/Product');
const { protect } = require('../middleware/auth');

// All cart routes require login
router.use(protect);

// ─────────────────────────────────────────────────────────────
// GET /api/cart
// Get current user's cart
// ─────────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user._id })
      .populate('items.product', 'name images price stock');

    if (!cart) {
      return res.json({ items: [], totalPrice: 0 });
    }

    // Calculate total
    const totalPrice = cart.items.reduce((total, item) => {
      return total + (item.price * item.quantity);
    }, 0);

    res.json({ ...cart.toObject(), totalPrice });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/cart
// Add item to cart
// Body: { productId, quantity, size, color }
// ─────────────────────────────────────────────────────────────
router.post('/', async (req, res) => {
  try {
    const { productId, quantity = 1, size, color } = req.body;

    // Check product exists and has stock
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    if (product.stock < quantity) {
      return res.status(400).json({ message: 'Not enough stock available' });
    }

    // Find or create cart
    let cart = await Cart.findOne({ user: req.user._id });
    if (!cart) {
      cart = new Cart({ user: req.user._id, items: [] });
    }

    // Check if item already in cart (same product + size + color)
    const existingIndex = cart.items.findIndex(item =>
      item.product.toString() === productId &&
      item.size  === size &&
      item.color === color
    );

    if (existingIndex >= 0) {
      // Update quantity
      cart.items[existingIndex].quantity += quantity;
    } else {
      // Add new item
      cart.items.push({
        product:  productId,
        quantity,
        size,
        color,
        price: product.price   // snapshot current price
      });
    }

    await cart.save();
    await cart.populate('items.product', 'name images price stock');

    const totalPrice = cart.items.reduce((t, i) => t + i.price * i.quantity, 0);
    res.json({ ...cart.toObject(), totalPrice });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// PUT /api/cart/:itemId
// Update item quantity in cart
// Body: { quantity }
// ─────────────────────────────────────────────────────────────
router.put('/:itemId', async (req, res) => {
  try {
    const { quantity } = req.body;
    const cart = await Cart.findOne({ user: req.user._id });

    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    const item = cart.items.id(req.params.itemId);
    if (!item) return res.status(404).json({ message: 'Item not found in cart' });

    if (quantity <= 0) {
      // Remove item if quantity is 0
      item.deleteOne();
    } else {
      item.quantity = quantity;
    }

    await cart.save();
    await cart.populate('items.product', 'name images price stock');

    const totalPrice = cart.items.reduce((t, i) => t + i.price * i.quantity, 0);
    res.json({ ...cart.toObject(), totalPrice });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// DELETE /api/cart/:itemId
// Remove a single item from cart
// ─────────────────────────────────────────────────────────────
router.delete('/:itemId', async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user._id });
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    cart.items = cart.items.filter(
      item => item._id.toString() !== req.params.itemId
    );

    await cart.save();
    res.json({ message: 'Item removed', itemCount: cart.items.length });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
// DELETE /api/cart
// Clear entire cart
// ─────────────────────────────────────────────────────────────
router.delete('/', async (req, res) => {
  try {
    await Cart.findOneAndDelete({ user: req.user._id });
    res.json({ message: 'Cart cleared' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
